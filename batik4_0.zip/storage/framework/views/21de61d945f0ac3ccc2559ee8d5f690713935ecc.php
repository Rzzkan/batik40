
<?php $__env->startSection('content'); ?>
<div class="page-inner mt-2">
    <div class="row">

        <div class="col-md-8">
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(Session('success')); ?>

            </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <div class="card-head-row">
                        <strong><i class="fas fa-align-left mr-2"> </i> Data Keranjang</strong>
                    </div>
                </div>
                <div class="card-body">
                    <div class="col-12">

                        <?php $__currentLoopData = $get_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($dt->status != 2): ?>

                        <div class="row">
                            <div class="col-3">
                                <img src="<?php echo e($data['data_setting']->base_url_img_desain_batik . '/' . $dt->file_batik); ?>" width="100%" style="border: 1px solid gray;">
                            </div>
                            <div class="col">
                                <strong><?php echo e(strtoupper($dt->nama_batik)); ?></strong>
                                <p class="card-text">
                                    <?php echo e("Warna: " . $dt->nama_warna . ", teknik: " . $dt->nama_teknik . ", kain: " . $dt->nama_kain . " | Jumlah: " . $dt->jumlah . " | ukuran kain: " . $dt->lebar_kain . " cm x " . $dt->tinggi_kain . " cm"); ?>

                                    <br>
                                    <?php
                                    $total_harga_produk = ($dt->biaya_mesin + $dt->biaya_warna + $dt->biaya_teknik + $dt->biaya_kain) * $dt->jumlah * (($dt->lebar_kain / 100) * ($dt->tinggi_kain / 100));
                                    ?>
                                    <strong><?php echo e("Rp " . number_format($total_harga_produk,2,',','.')); ?></strong>
                                </p>
                                <button class="btn btn-sm btn-info" data-toggle="modal" data-target="#ubah<?php echo e($dt->id); ?>"><i class="mr-2 fa fa-check-circle" aria-hidden="true"></i> Ubah</button>
                                <button class="btn btn-sm btn-danger" data-toggle="modal" data-target="#hapuskeranjang<?php echo e($dt->id); ?>"><i class="mr-2 fas fa-trash-alt" aria-hidden="true"></i> Hapus</button>

                                <div class="modal fade" id="hapuskeranjang<?php echo e($dt->id); ?>">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">

                                            <div class="modal-header">
                                                <h5 class="modal-title"><strong>Hapus Data <?php echo e($dt->nama_batik); ?> ?</strong></h5>
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            </div>

                                            <div class="modal-body">
                                                <form action="<?php echo e(route('keranjang.destroy', $dt->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>

                                                    <div class="col text-center">
                                                        <p>Tekan <strong>Hapus</strong> untuk menghapus data <?php echo e($dt->nama_batik); ?> ! </p>

                                                        <button class="btn btn-danger btn-sm" type="submit">Hapus</button>
                                                        <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Batal</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="modal fade" id="ubah<?php echo e($dt->id); ?>">
                                    <div class="modal-dialog modal-dialog-centered modal-lg">
                                        <div class="modal-content">

                                            <div class="modal-header">
                                                <h5 class="modal-title"><strong>Ubah Keranjang <?php echo e(strtoupper($dt->nama_batik)); ?> ?</strong></h5>
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            </div>

                                            <div class="modal-body">
                                                <form class="col" action="<?php echo e(route('keranjang.update', $dt->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>

                                                    <div class="row">
                                                        <div class="col-12 text-center">
                                                            <img src="<?php echo e($data['data_setting']->base_url_img_desain_batik . '/' . $dt->file_batik); ?>" height="80px" style="border: 1px solid gray;">

                                                            <p>
                                                                <?php echo e("Warna: " . $dt->nama_warna . ", teknik: " . $dt->nama_teknik . ", kain: " . $dt->nama_kain); ?>

                                                            </p>
                                                        </div>

                                                        <div class="form-group col-md-6 input-group-sm">
                                                            <label for="sel1">Pilih Warna:</label>
                                                            <select class="form-control" id="inpWarna" name="inpWarna">
                                                                <?php $__currentLoopData = $warna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($dt->id_warna == $dtw->id): ?>
                                                                <option value="<?php echo e($dtw->id); ?>"><?php echo e($dtw->nama .' (Rp ' . number_format(($dtw->biaya),2,',','.') . ')'); ?></option>
                                                                <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                <?php $__currentLoopData = $warna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($dt->id_warna != $dtw->id): ?>
                                                                <option value="<?php echo e($dtw->id); ?>"><?php echo e($dtw->nama .' (Rp ' . number_format(($dtw->biaya),2,',','.') . ')'); ?></option>
                                                                <?php endif; ?>

                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>

                                                        <div class="form-group col-md-6 input-group-sm">
                                                            <label for="inpTeknik">Pilih Teknik Warna:</label>
                                                            <select class="form-control" id="inpTeknik" name="inpTeknik">
                                                                <?php $__currentLoopData = $teknik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                <?php if($dt->id_teknik == $dtt->id): ?>
                                                                <option value="<?php echo e($dtt->id); ?>"><?php echo e($dtt->nama .' (Rp ' . number_format(($dtt->biaya),2,',','.') . ')'); ?></option>
                                                                <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                <?php $__currentLoopData = $teknik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($dt->id_teknik != $dtt->id): ?>
                                                                <option value="<?php echo e($dtt->id); ?>"><?php echo e($dtt->nama .' (Rp ' . number_format(($dtt->biaya),2,',','.') . ')'); ?></option>
                                                                <?php endif; ?>

                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>

                                                        <div class="form-group col-md-6 input-group-sm">
                                                            <label for="inpKain">Pilih Kain:</label>
                                                            <select class="form-control" id="inpKain" name="inpKain">
                                                                <?php $__currentLoopData = $kain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                <?php if($dt->id_kain == $dtk->id): ?>
                                                                <option value="<?php echo e($dtk->id); ?>"><?php echo e($dtk->nama .' (Rp ' . number_format(($dtk->biaya),2,',','.') . ')'); ?></option>
                                                                <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                <?php $__currentLoopData = $kain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($dt->id_kain != $dtk->id): ?>
                                                                <option value="<?php echo e($dtk->id); ?>"><?php echo e($dtk->nama .' (Rp ' . number_format(($dtk->biaya),2,',','.') . ')'); ?></option>
                                                                <?php endif; ?>

                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>

                                                        <div class="col-md-6 form-group input-group-sm">
                                                            <label for="inpJumlah">Jumlah Produk:</label>
                                                            <input type="number" class="form-control" placeholder="" id="inpJumlah" name="inpJumlah" value="<?php echo e($dt->jumlah); ?>">
                                                        </div>

                                                        <div class="col-md-6 form-group input-group-sm">
                                                            <div class="form-check-inline">
                                                                <label class="form-check-label">
                                                                    <input type="checkbox" name="inpStatus" class="form-check-input" value="1" <?php if($dt->status == 1): ?> checked <?php endif; ?>>Pilih produk ini untuk dibayar!
                                                                </label>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-12 form-group input-group-sm">
                                                            <button class="btn btn-primary btn-sm" type="submit">Simpan</button>
                                                            <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Batal</button>
                                                        </div>

                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="col-1">
                                <i class="fa fa-check-circle <?php if($dt->status == 1): ?> text-success <?php endif; ?> " aria-hidden="true"></i>
                            </div>
                        </div>
                        <hr>

                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <div class="card-head-row">
                        <strong><i class="fas fa-credit-card mr-2"> </i> Total Keranjang</strong>
                    </div>
                </div>
                <div class="card-body">
                    <div class="col-12">

                        <?php
                        $no = 1;
                        $total = 0;
                        $berat = 0;
                        $id_ker = "";
                        ?>
                        <?php $__currentLoopData = $get_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($dt->status == 1): ?>

                        <?php
                        $harga_item = $total_harga_produk;
                        $total = $total + $harga_item;
                        $berat = $berat + ($dt->berat_kain * $dt->jumlah);
                        $id_ker = $id_ker . "--" . $dt->id;
                        ?>

                        <div class="row">
                            <div class="col-1">
                                <?php echo e($no++); ?>

                            </div>
                            <div class="col">
                                <p class="card-text">
                                    <strong>
                                        <?php echo e(strtoupper($dt->nama_batik)); ?>

                                    </strong>
                                    <br>
                                    <?php echo e("Rp " . number_format(($harga_item),2,',','.')); ?>

                                </p>
                            </div>
                        </div>
                        <hr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <h5><strong>Total Pesanan : <?php echo e("Rp " . number_format(($total),2,',','.')); ?></strong></h5>
                        <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#tambahTransaksi"><i class="fas fa-credit-card mr-2"> </i> Pesan Sekarang</button>

                        <div class="modal fade" id="tambahTransaksi">
                            <div class="modal-dialog modal-dialog-centered modal-lg">
                                <div class="modal-content">

                                    <div class="modal-header">
                                        <h5 class="modal-title"><strong>Melakukan Pemesanan</strong></h5>
                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    </div>

                                    <div class="modal-body">
                                        <form action="<?php echo e(route('transaksi.store')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('POST'); ?>
                                            <div class="col-md-6 form-group input-group-sm" hidden>
                                                <input type="number" class="form-control" placeholder="" id="inpBerat" name="inpBerat" value="<?php echo e($berat); ?>">
                                            </div>

                                            <div class="col-md-6 form-group input-group-sm">
                                                <input type="number" class="form-control" placeholder="" id="inpTotal" name="inpTotal" value="<?php echo e($total); ?>">
                                            </div>

                                            <div class="col-md-6 form-group input-group-sm" hidden>
                                                <input type="text" class="form-control" placeholder="" id="inpIdker" name="inpIdker" value="<?php echo e($id_ker); ?>">
                                            </div>

                                            <div class="col">
                                                <strong class="">Pilih alamat pengiriman: </strong>
                                                <br>

                                                <?php $__currentLoopData = $alamat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <div class="col-md-12 mt-3">
                                                    <div class="row border p-2 mb-3">
                                                        <div class="">
                                                            <input type="radio" name="inpAlamat" id="inpAlamat<?php echo e($dtal->id); ?>" value="<?php echo e($dtal->id); ?>">
                                                        </div>
                                                        <label class="col" for="inpAlamat<?php echo e($dtal->id); ?>"><?php echo e('(' . $dtal->penerima . ') ' . $dtal->alamat); ?></label>
                                                    </div>
                                                </div>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <!-- <p>Dengan menekan tombol <strong>Lakukan Pemesanan</strong> maka proses akan dilanjutkan pada menu transaksi! </p> -->

                                                <button class="btn btn-primary btn-sm" type="submit">Lanjutkan Pemesanan</button>
                                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Batal</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyek\batik4_0\resources\views/customer/keranjang/index.blade.php ENDPATH**/ ?>