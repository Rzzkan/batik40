
<?php $__env->startSection('content'); ?>
<div class="page-inner mt--5">
    <div class="row">

        <div class="col-md-12">
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(Session('success')); ?>

            </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <div class="card-head-row">
                        <strong><i class="fas fa-align-left mr-2"> </i> Data Antrian Mesin</strong>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="basic-datatables" class="table table-bordered table-hover">
                            <thead class="thead-light">
                                <tr>
                                    <th>No.</th>
                                    <th>Nama Mesin</th>
                                    <th>Kode</th>
                                    <th>Antrian</th>
                                    <th>Status</th>
                                    <th>Tindakan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                ?>
                                <?php $__empty_1 = true; $__currentLoopData = $antrian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($dt->nama); ?></td>
                                    <td><?php echo e($dt->kode); ?></td>
                                    <td><?php echo e($dt->jumlah_antrian); ?></td>
                                    <td>
                                        <?php if($dt->status == 'Bekerja'): ?>
                                        <button type="button" class="btn btn-success btn-sm">
                                            <i class="fas fa-check mr-2"> </i> <?php echo e($dt->status); ?>

                                        </button>
                                        <?php elseif($dt->status == 'Idle'): ?>
                                        <button type="button" class="btn btn-warning btn-sm">
                                            <i class="fas fa-hourglass-end mr-2"> </i> <?php echo e($dt->status); ?>

                                        </button>
                                        <?php else: ?>
                                        <button type="button" class="btn btn-danger btn-sm">
                                            <i class="fas fa-exclamation mr-2"> </i> <?php echo e($dt->status); ?>

                                        </button>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('antrian.show', $dt->id)); ?>" type="button" class="btn btn-secondary btn-sm">
                                            <i class="fas fa-clipboard-list mr-2"> </i> Detail
                                        </a>
                                    </td>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6">Data Kosong...</td>
                                </tr>
                                <?php endif; ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyek\batik4_0\resources\views/content/antrian/index.blade.php ENDPATH**/ ?>