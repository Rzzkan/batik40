
<?php $__env->startSection('content'); ?>
<div class="page-inner mt-2">
    <div class="row">

        <div class="col-md-12 mb-3">
            <div class="row">
                <div class="col"><a href="<?php echo e(route('transaksi.show', 'validasi')); ?>" class="col btn btn-sm <?php if($posisi == 'validasi'): ?> btn-primary <?php else: ?> btn-outline-primary <?php endif; ?> "><i class="fa fa-check-square mr-2"> </i> Validasi</a></div>
                <div class="col"><a href="<?php echo e(route('transaksi.show', 'belum_dibayar')); ?>" class="col btn btn-sm <?php if($posisi == 'belum_dibayar'): ?> btn-primary <?php else: ?> btn-outline-primary <?php endif; ?> "><i class="fas fa-credit-card mr-2"> </i> Belum Dibayar</a></div>
                <div class="col"><a href="<?php echo e(route('transaksi.show', 'diproses')); ?>" class="col btn btn-sm <?php if($posisi == 'diproses'): ?> btn-primary <?php else: ?> btn-outline-primary <?php endif; ?> "><i class="fa fa-hourglass-start mr-2"> </i> Diproses</a></div>
                <div class="col"><a href="<?php echo e(route('transaksi.show', 'dikemas')); ?>" class="col btn btn-sm <?php if($posisi == 'dikemas'): ?> btn-primary <?php else: ?> btn-outline-primary <?php endif; ?> "><i class="fas fa-shopping-bag mr-2"> </i> Dikemas</a></div>
                <div class="col"><a href="<?php echo e(route('transaksi.show', 'dikirim')); ?>" class="col btn btn-sm <?php if($posisi == 'dikirim'): ?> btn-primary <?php else: ?> btn-outline-primary <?php endif; ?> "><i class="fa fa-truck mr-2"> </i> Dikirim</a></div>
                <div class="col"><a href="<?php echo e(route('transaksi.show', 'selesai')); ?>" class="col btn btn-sm <?php if($posisi == 'selesai'): ?> btn-primary <?php else: ?> btn-outline-primary <?php endif; ?> "><i class="fas fa-people-carry mr-2"> </i> Selesai</a></div>
                <div class="col"><a href="<?php echo e(route('transaksi.show', 'dibatalkan')); ?>" class="col btn btn-sm <?php if($posisi == 'dibatalkan'): ?> btn-primary <?php else: ?> btn-outline-primary <?php endif; ?> "><i class="fas fa-window-close mr-2"> </i> Dibatalkan</a></div>
            </div>
            <hr>
        </div>

        <?php $__currentLoopData = $get_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="col-md-8">
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(Session('success')); ?>

            </div>
            <?php endif; ?>
            <?php if(Session::has('failed')): ?>
            <div class="alert alert-danger">
                <?php echo e(Session('failed')); ?>

            </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">
                    <div class="card-head-row">
                        <strong><i class="fas fa-shopping-bag mr-2"> </i> Data Transaksi: BTK<?php echo e($dto->id); ?>RK</strong>
                    </div>
                </div>
                <div class="card-body">
                    <div class="col-12">

                        <?php $__currentLoopData = $dto->produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($dt->status == 2): ?>

                        <div class="row">
                            <div class="col-2">
                                <img src="<?php echo e($data['data_setting']->base_url_img_desain_batik . '/' . $dt->file_batik); ?>" width="100%" style="border: 1px solid gray;">
                            </div>
                            <div class="col">
                                <strong><?php echo e(strtoupper($dt->nama_batik)); ?></strong>
                                <p class="card-text">
                                    <?php echo e("Warna: " . $dt->nama_warna . ", teknik: " . $dt->nama_teknik . ", kain: " . $dt->nama_kain . " | Jumlah: " . $dt->jumlah . " | ukuran kain: " . $dt->lebar_kain . " cm x " . $dt->tinggi_kain . " cm"); ?>

                                    <br>
                                    <?php
                                    $total_harga_produk = ($dt->biaya_mesin + $dt->biaya_warna + $dt->biaya_teknik + $dt->biaya_kain) * $dt->jumlah * (($dt->lebar_kain / 100) * ($dt->tinggi_kain / 100));
                                    ?>
                                    <strong><?php echo e("Rp " . number_format($total_harga_produk,2,',','.')); ?></strong>
                                </p>

                            </div>
                        </div>
                        <hr>

                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>

        </div>

        <div class="col-md-4">

            <div class="card">
                <div class="card-header">
                    <div class="card-head-row">
                        <strong><i class="fas fa-clipboard-list mr-2"> </i> Data Transaksi: BTK<?php echo e($dto->id); ?>RK</strong>
                    </div>
                </div>

                <!--Validasi-->
                <?php if($posisi == 'validasi'): ?>
                <div class="card-body">
                    <strong>Pesanan Sedang Divalidasi!</strong>
                    <p class="text-danger">
                        Pesanan anda dalam proses validasi oleh tim kami. Mohon tunggu beberapa saat atau hubungi kami.
                    </p>
                    <a href="https://api.whatsapp.com/send?phone=<?php echo e($data['data_setting']->no_toko); ?>" target="_blank" class="btn btn-sm btn-success"><i class="fab fa-whatsapp mr-2"> </i> Whatsapp</a>
                </div>
                <?php endif; ?>

                <!--belum bayar-->
                <?php if($posisi == 'belum_dibayar'): ?>
                <div class="card-body">
                    <strong>Alamat Pengiriman:</strong>
                    <p>
                        <?php if($dto->ro_cost > 0): ?>
                        <?php echo e("Rp " . number_format($dto->ro_cost,2,',','.') . " | " . $dto->ro_etd . " | " . $dto->ro_name . " | " . $dto->ro_description . " | (" . $dto->ro_service . ")"); ?>

                        <?php else: ?>
                        Belum memilih metode pengiriman.
                        <?php endif; ?>
                    </p>
                    <button class="btn btn-sm btn-info" data-toggle="modal" data-target="#pengiriman<?php echo e($dto->id); ?>"><i class="fa fa-truck mr-2" aria-hidden="true"></i> Pilih Pengiriman</button>

                    <div class="modal fade" id="pengiriman<?php echo e($dto->id); ?>">
                        <div class="modal-dialog modal-dialog-centered modal-lg">
                            <div class="modal-content">

                                <div class="modal-header">
                                    <h5 class="modal-title"><strong><i class="fa fa-truck mr-2" aria-hidden="true"></i> Pilih Pengiriman </strong></h5>
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>

                                <div class="modal-body">
                                    <form class="col" action="<?php echo e(route('transaksi.update', $dto->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class="row">

                                            <div class="col-md-6 form-group input-group-sm">
                                                <label for="country">Expedisi</label>
                                                <select class="form-control" id="expedisi-dropdown" name="inpExpedisi">
                                                    <option value="">Pilih Expedisi</option>
                                                    <option value="<?php echo e($data['data_setting']->id_kec_toko . '---' . $dto->id_kec .'---'. $dto->berat . '---pos'); ?>">pos</option>
                                                    <option value="<?php echo e($data['data_setting']->id_kec_toko . '---' . $dto->id_kec .'---'. $dto->berat . '---tiki'); ?>">tiki</option>
                                                    <option value="<?php echo e($data['data_setting']->id_kec_toko . '---' . $dto->id_kec .'---'. $dto->berat . '---jne'); ?>">jne</option>
                                                    <option value="<?php echo e($data['data_setting']->id_kec_toko . '---' . $dto->id_kec .'---'. $dto->berat . '---pcp'); ?>">pcp</option>
                                                    <option value="<?php echo e($data['data_setting']->id_kec_toko . '---' . $dto->id_kec .'---'. $dto->berat . '---esl'); ?>">esl</option>
                                                    <option value="<?php echo e($data['data_setting']->id_kec_toko . '---' . $dto->id_kec .'---'. $dto->berat . '---rpx'); ?>">rpx</option>
                                                    <option value="<?php echo e($data['data_setting']->id_kec_toko . '---' . $dto->id_kec .'---'. $dto->berat . '---pandu'); ?>">pandu</option>
                                                    <option value="<?php echo e($data['data_setting']->id_kec_toko . '---' . $dto->id_kec .'---'. $dto->berat . '---wahana'); ?>">wahana</option>
                                                    <option value="<?php echo e($data['data_setting']->id_kec_toko . '---' . $dto->id_kec .'---'. $dto->berat . '---jnt'); ?>">jnt</option>
                                                    <option value="<?php echo e($data['data_setting']->id_kec_toko . '---' . $dto->id_kec .'---'. $dto->berat . '---pahala'); ?>">pahala</option>
                                                    <option value="<?php echo e($data['data_setting']->id_kec_toko . '---' . $dto->id_kec .'---'. $dto->berat . '---cahaya'); ?>">cahaya</option>
                                                    <option value="<?php echo e($data['data_setting']->id_kec_toko . '---' . $dto->id_kec .'---'. $dto->berat . '---sap'); ?>">sap</option>
                                                    <option value="<?php echo e($data['data_setting']->id_kec_toko . '---' . $dto->id_kec .'---'. $dto->berat . '---jet'); ?>">jet</option>
                                                    <option value="<?php echo e($data['data_setting']->id_kec_toko . '---' . $dto->id_kec .'---'. $dto->berat . '---indah'); ?>">indah</option>
                                                    <option value="<?php echo e($data['data_setting']->id_kec_toko . '---' . $dto->id_kec .'---'. $dto->berat . '---dse'); ?>">dse</option>
                                                    <option value="<?php echo e($data['data_setting']->id_kec_toko . '---' . $dto->id_kec .'---'. $dto->berat . '---slis'); ?>">slis</option>
                                                    <option value="<?php echo e($data['data_setting']->id_kec_toko . '---' . $dto->id_kec .'---'. $dto->berat . '---first'); ?>">first</option>
                                                    <option value="<?php echo e($data['data_setting']->id_kec_toko . '---' . $dto->id_kec .'---'. $dto->berat . '---ncs'); ?>">ncs</option>
                                                    <option value="<?php echo e($data['data_setting']->id_kec_toko . '---' . $dto->id_kec .'---'. $dto->berat . '---star'); ?>">star</option>
                                                </select>
                                            </div>

                                            <div class="col-md-6 form-group input-group-sm">
                                                <label for="state">Pilih Pengiriman</label>
                                                <select class="form-control" id="price-dropdown" name="inpPengiriman">
                                                </select>
                                            </div>

                                            <div class="col-md-12 form-group input-group-sm">
                                                <input class="btn btn-primary btn-sm" type="submit" class="form-control" value="Pilih Pengiriman">
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <hr>

                    <strong>Total Harga Fix : </strong>
                    <h4>
                        <strong>
                            <?php echo e("Rp " . number_format(($dto->ro_cost + $dto->total),2,',','.')); ?>

                        </strong>
                    </h4>

                    <?php if($dto->sudah_dibayar == 0): ?>
                    <button class="btn btn-danger btn-sm disabled"><i class="fas fa-credit-card mr-2"> </i> Belum Dibayar</button>
                    <?php elseif($dto->sudah_dibayar == 1): ?>
                    <button class="btn btn-warning btn-sm disabled"><i class="fas fa-credit-card mr-2"> </i> Cek Pembayaran</button>
                    <?php else: ?>
                    <button class="btn btn-success btn-sm disabled"><i class="fas fa-credit-card mr-2"> </i> Sudah Dibayar</button>
                    <?php endif; ?>

                    <hr>

                    <button class="btn btn-sm btn-primary mb-2" data-toggle="modal" data-target="#bayar<?php echo e($dto->id); ?>" <?php if($dto->ro_cost < 1): ?> disabled <?php endif; ?>><i class="fas fa-credit-card mr-2" aria-hidden="true"></i> Bayar</button>

                    <button class="btn btn-sm btn-success mb-2" data-toggle="modal" data-target="#konfirm_bayar<?php echo e($dto->id); ?>" <?php if($dto->ro_cost < 1): ?> disabled <?php endif; ?>><i class="fas fa-credit-card mr-2" aria-hidden="true"></i> Konfirmasi Pembarayan</button>

                    <button class="btn btn-sm btn-danger mb-2" data-toggle="modal" data-target="#batal<?php echo e($dto->id); ?>"><i class="fas fa-window-close mr-2" aria-hidden="true"></i> Batalkan Pesanan</button>


                    <div class="modal fade" id="konfirm_bayar<?php echo e($dto->id); ?>">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">

                                <div class="modal-header">
                                    <h5 class="modal-title"><strong><i class="fas fa-credit-card mr-2" aria-hidden="true"></i> Pembayaran </strong></h5>
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>

                                <div class="modal-body">
                                    <form class="col" action="<?php echo e(url('sudah_bayar')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('POST'); ?>
                                        <div class="col-12 text-center">
                                            <strong>Yakin sudah melakukan pembayaran pada produk BTK<?php echo e($dto->id); ?>RK? Tekan "Sudah Bayar" agar segera kami proses!</strong>
                                            <div class="col-md-6 form-group input-group-sm" hidden>
                                                <label for="inpIdTransaksi">ID Bayar</label>
                                                <input type="text" class="form-control" placeholder="" value="<?php echo e($dto->id); ?>" id="inpIdTransaksi" name="inpIdTransaksi">
                                            </div>

                                            <div class="col-md-12 form-group input-group-sm">
                                                <input class="btn btn-primary btn-sm" type="submit" class="form-control" value="Sudah Bayar">
                                            </div>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="modal fade" id="bayar<?php echo e($dto->id); ?>">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">

                                <div class="modal-header">
                                    <h5 class="modal-title"><strong><i class="fas fa-credit-card mr-2" aria-hidden="true"></i> Pembayaran </strong></h5>
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>

                                <div class="modal-body">
                                    <form class="col" action="<?php echo e(url('bayar_pesanan')); ?>" method="POST" target="_blank">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('POST'); ?>
                                        <div class="col-12 text-center">
                                            <strong>Yakin akan melakukan pembayaran pada produk BTK<?php echo e($dto->id); ?>RK? Tekan "Bayar Sekarang" untuk melakukan pembayaran!</strong>
                                            <div class="col-md-6 form-group input-group-sm" hidden>
                                                <label for="inpIdTransaksi">ID Bayar</label>
                                                <input type="text" class="form-control" placeholder="" value="<?php echo e($dto->id); ?>" id="inpIdTransaksi" name="inpIdTransaksi">
                                            </div>

                                            <div class="col-md-12 form-group input-group-sm">
                                                <input class="btn btn-primary btn-sm" type="submit" class="form-control" value="Bayar Sekarang">
                                            </div>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="modal fade" id="batal<?php echo e($dto->id); ?>">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">

                                <div class="modal-header">
                                    <h5 class="modal-title"><strong><i class="fas fa-credit-card mr-2" aria-hidden="true"></i> Batalkan Pesanan </strong></h5>
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>

                                <div class="modal-body">
                                    <form class="col" action="<?php echo e(url('batal_pesanan')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('POST'); ?>
                                        <div class="col-12 text-center">
                                            <strong>Yakin akan membatalkan pesanan pada produk BTK<?php echo e($dto->id); ?>RK? Tekan "Batalkan" untuk melakukan pembatalan pesanan!</strong>
                                            <div class="col-md-6 form-group input-group-sm" hidden>
                                                <label for="inpIdTransaksi">ID Bayar</label>
                                                <input type="text" class="form-control" placeholder="" value="<?php echo e($dto->id); ?>" id="inpIdTransaksi" name="inpIdTransaksi">
                                            </div>

                                            <div class="col-md-12 form-group input-group-sm">
                                                <input class="btn btn-danger btn-sm" type="submit" class="form-control" value="Batalkan">
                                            </div>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <?php endif; ?>

                <!--proses-->
                <?php if($posisi == 'diproses'): ?>
                <div class="card-body">
                    <strong>Pesanan Sedang Diproses!</strong>
                    <p class="text-danger">
                        Pesanan anda dalam proses produksi oleh tim kami. Tekan tombol dibawah untuk mengetahui proses produksi produk anda.
                    </p>

                    <!-- <button class="btn btn-sm btn-success"><i class="fab fa-whatsapp mr-2"> </i> Lihat Detail</button> -->

                    <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#detail<?php echo e($dto->id); ?>"><i class="fas fa-clipboard-list mr-2" aria-hidden="true"></i> Lihat Detail</button>

                    <div class="modal fade" id="detail<?php echo e($dto->id); ?>">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">

                                <div class="modal-header">
                                    <h5 class="modal-title"><strong><i class="fas fa-credit-card mr-2" aria-hidden="true"></i> Proses Produksi </strong></h5>
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>

                                <div class="modal-body">

                                    <div class="container py-2 mb-4">
                                        <?php
                                        $no = 1;
                                        ?>
                                        <?php $__currentLoopData = $dto->log_proses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="row">
                                            <!-- timeline item 1 left dot -->
                                            <div class="col-auto text-center flex-column d-none d-sm-flex">
                                                <div class="row h-50">
                                                    <div class="col <?php if($no != 1): ?> border-right <?php endif; ?> ">&nbsp;</div>
                                                    <div class="col">&nbsp;</div>
                                                </div>
                                                <h5 class="m-2">
                                                    <span class="badge badge-pill <?php if($dto->id_proses == $dt->id_proses): ?> bg-success <?php else: ?> bg-warning <?php endif; ?> border">&nbsp;</span>
                                                </h5>
                                                <div class="row h-50">
                                                    <div class="col <?php if($no != count($dto->log_proses) && count($dto->log_proses) != 1): ?> border-right <?php endif; ?> ">&nbsp;</div>
                                                    <div class="col">&nbsp;</div>
                                                </div>
                                            </div>
                                            <!-- timeline item 1 event content -->
                                            <div class="col">
                                                <div class="card">
                                                    <div class="card-body">
                                                        <div class="">
                                                            <?php echo e($dt->updated_at); ?>

                                                        </div>
                                                        <p class="card-text">
                                                            <strong>
                                                                <?php echo e($dt->nama_proses); ?>

                                                            </strong>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <strong hidden><?php echo e($no++); ?></strong>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <?php endif; ?>

                <!--dikemas-->
                <?php if($posisi == 'dikemas'): ?>
                <div class="card-body">
                    <strong>Pesanan Sedang Dikemas!</strong>
                    <p class="text-primary">
                        Pesanan anda dalam proses pengemasan oleh tim kami.
                    </p>
                </div>
                <?php endif; ?>

                <!--dikirim-->
                <?php if($posisi == 'dikirim'): ?>
                <div class="card-body">
                    <strong>Pesanan Sedang Dikirim!</strong>
                    <p class="text-primary">
                        Pesanan anda dalam proses mengiriman oleh tim kami. Tekan tombol dibawah untuk melacak pengiriman.
                    </p>

                    <strong>Resi: <?php if($dto->resi != null): ?> <?php echo e($dto->resi); ?> <?php else: ?> - <?php endif; ?> <br>Expedisi: <?php echo e($dto->ro_code); ?></strong>
                    <br>
                    <a href="https://everpro.id/cek-resi/" target="_blank" class="btn btn-sm btn-success mt-2"><i class="fa fa-truck mr-2"> </i> Lacak Produk</a>
                </div>
                <?php endif; ?>

                <?php if($posisi == 'selesai'): ?>
                <!--selesai-->
                <div class="card-body">
                    <strong>Pesanan Telah Diterima</strong>
                    <p class="text-primary">
                        Pesanan anda telah diserahkan ke penerima. Anda dapat memberikan review dan komentar dengan menekan tombol dibawah.
                    </p>

                    <button class="btn btn-sm btn-info" data-toggle="modal" data-target="#review<?php echo e($dto->id); ?>"><i class="far fa-star mr-2" aria-hidden="true"></i> Beri Review</button>

                    <div class="modal fade" id="review<?php echo e($dto->id); ?>">
                        <div class="modal-dialog modal-dialog-centered modal-lg">
                            <div class="modal-content">

                                <div class="modal-header">
                                    <h5 class="modal-title"><strong><i class="far fa-star mr-2" aria-hidden="true"></i> Beri Review </strong></h5>
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>

                                <div class="modal-body">
                                    <form class="col" action="<?php echo e(route('review.update', $dto->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class="row">

                                            <!-- <div class="col-md-6 form-group input-group-sm">
                                                <label for="inpIdTransaksi">ID Bayar</label>
                                                <input type="text" class="form-control" placeholder="" value="<?php echo e($dto->id); ?>" id="inpIdTransaksi" name="inpIdTransaksi">
                                            </div> -->

                                            <div class="col-md-12 form-group input-group-sm">
                                                <label for="inpKomentar">Beri Review</label>
                                                <textarea type="text" class="form-control" placeholder="" id="inpKomentar" name="inpKomentar"><?php echo e($dto->komentar); ?></textarea>
                                            </div>

                                            <div class="col-md-12 form-group input-group-sm">
                                                <input class="btn btn-primary btn-sm" type="submit" class="form-control" value="Simpan Review">
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <?php endif; ?>

                <!--dibatalkan-->
                <?php if($posisi == 'dibatalkan'): ?>
                <div class="card-body">
                    <strong>Pesanan Dibatalkan!</strong>
                    <p class="text-danger">
                        Pesanan anda dibatalkan pada tanggal <?php echo e($dto->updated_at); ?>

                    </p>
                </div>
                <?php endif; ?>

            </div>
        </div>

        <hr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyek\batik4_0\resources\views/customer/transaksi/index.blade.php ENDPATH**/ ?>