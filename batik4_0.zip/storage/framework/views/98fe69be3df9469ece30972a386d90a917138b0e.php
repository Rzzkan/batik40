
<?php $__env->startSection('content'); ?>
<div class="page-inner mt-2">
    <div class="row">

        <div class="col-md-12">
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(Session('success')); ?>

            </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <div class="card-head-row">
                        <strong><i class="fas fa-align-left mr-2"> </i> Data Alamat</strong>
                        <a href="<?php echo e(route('alamat.create')); ?>" class="btn btn-primary btn-sm ml-auto"><i class="fas fa-plus mr-2"> </i> Tambah Alamat</a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="basic-datatables" class="table table-bordered table-hover">
                            <thead class="thead-light">
                                <tr>
                                    <th>No.</th>
                                    <th>Nama Penerima</th>
                                    <th>No. Hp</th>
                                    <th>Alamat</th>
                                    <th>Keterangan</th>
                                    <th>Kecamatan</th>
                                    <th>Tindakan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                ?>
                                <?php $__empty_1 = true; $__currentLoopData = $alamat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($dt->penerima); ?></td>
                                    <td><?php echo e($dt->no_hp); ?></td>
                                    <td><?php echo e($dt->alamat); ?></td>
                                    <td><?php echo e($dt->alias); ?></td>
                                    <td><?php echo e($dt->nama_kec); ?></td>

                                    <td>
                                        <div class="dropdown">
                                            <button type="button" class="btn btn-secondary btn-sm dropdown-toggle" data-toggle="dropdown">
                                                Tindakan
                                            </button>
                                            <div class="dropdown-menu">
                                                <a class="dropdown-item" href="<?php echo e(route('alamat.edit', $dt->id)); ?>">ubah</a>
                                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#hapusalamat<?php echo e($dt->id); ?>">Hapus</a>
                                            </div>
                                        </div>
                                    </td>

                                    <div class="modal fade" id="hapusalamat<?php echo e($dt->id); ?>">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content">

                                                <div class="modal-header">
                                                    <h5 class="modal-title"><strong>Hapus Data <?php echo e($dt->nama); ?> ?</strong></h5>
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                </div>

                                                <div class="modal-body">
                                                    <form action="<?php echo e(route('alamat.destroy', $dt->id)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('delete'); ?>

                                                        <div class="col text-center">
                                                            <p>Tekan <strong>Hapus</strong> untuk menghapus data <?php echo e($dt->nama); ?> ! </p>

                                                            <button class="btn btn-danger btn-sm" type="submit">Hapus</button>
                                                            <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Batal</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7">Data Kosong...</td>
                                </tr>
                                <?php endif; ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyek\batik4_0\resources\views/customer/alamat/index.blade.php ENDPATH**/ ?>