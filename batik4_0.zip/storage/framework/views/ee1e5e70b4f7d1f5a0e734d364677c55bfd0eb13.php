<footer class="footer">
    <div class="container-fluid">
        <nav class="pull-left">
            <ul class="nav">

                <!-- <li class="nav-item">
                    <a class="nav-link" href="https://www.themekita.com">
                        ThemeKita
                    </a>
                </li> -->

            </ul>
        </nav>
        <div class="copyright ml-auto">
            Modified <i class="fa fa-heart heart text-danger"></i> by <a href="#">Batik 4.0</a>
        </div>
    </div>
</footer><?php /**PATH D:\proyek\batik4_0\resources\views/includes/footer.blade.php ENDPATH**/ ?>