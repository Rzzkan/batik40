
<?php $__env->startSection('content'); ?>

<div class="page-inner mt-2">
    <div class="row">

        <div class="col-md-12">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <div class="card-head-row">
                        <strong><i class="fas fa-pen mr-2"> </i> Form Alamat</strong><a href="<?php echo e(url()->previous()); ?>" class="btn btn-danger btn-sm ml-auto"><i class="fas fa-arrow-left mr-2"> </i> Back</a>
                    </div>
                </div>
                <div class="card-body">
                    <form class="col" method="POST" action="<?php echo e(route('alamat.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6 form-group input-group-sm">
                                <label for="penerima">Nama Penerima</label>
                                <input type="text" class="form-control" placeholder="" id="penerima" name="penerima">
                            </div>

                            <div class="col-md-6 form-group input-group-sm">
                                <label for="no_hp">Nomor HP</label>
                                <input type="text" class="form-control" placeholder="" id="no_hp" name="no_hp">
                            </div>

                            <div class="col-md-6 form-group input-group-sm" hidden>
                                <input type="text" class="form-control" placeholder="" id="nama_prov" name="nama_prov">
                            </div>

                            <div class="col-md-6 form-group input-group-sm" hidden>
                                <input type="text" class="form-control" placeholder="" id="nama_kab" name="nama_kab">
                            </div>

                            <div class="col-md-6 form-group input-group-sm" hidden>
                                <input type="text" class="form-control" placeholder="" id="nama_kec" name="nama_kec">
                            </div>

                            <div class="col-md-6 form-group input-group-sm">
                                <label for="country">Provinsi</label>
                                <select class="form-control" id="prov-dropdown" name="id_prov">
                                    <option value="">Pilih Provinsi</option>
                                    <?php $__currentLoopData = $data_prov; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($country['province_id'] . '---' . $country['province']); ?>">
                                        <?php echo e($country['province']); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-md-6 form-group input-group-sm">
                                <label for="state">Kota/Kabupaten</label>
                                <select class="form-control" id="kab-dropdown" name="id_kab">
                                </select>
                            </div>

                            <div class="col-md-6 form-group input-group-sm">
                                <label for="city">Kecamatan</label>
                                <select class="form-control" id="kac-dropdown" name="id_kec">
                                </select>
                            </div>

                            <div class="col-md-6 form-group input-group-sm">
                                <label for="alias">Keterangan (Rumah/Kantor/Kost)</label>
                                <input type="text" class="form-control" placeholder="" id="alias" name="alias">
                            </div>

                            <div class="col-md-6 form-group input-group-sm">
                                <label for="alamat">Alamat</label>
                                <textarea type="text" class="form-control" placeholder="" id="alamat" name="alamat"></textarea>
                            </div>

                            <div class="col-md-12 form-group input-group-sm">
                                <input class="btn btn-primary btn-sm" type="submit" class="form-control">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyek\batik4_0\resources\views/customer/alamat/create.blade.php ENDPATH**/ ?>