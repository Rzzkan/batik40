
<?php $__env->startSection('content'); ?>
<div class="page-inner mt--5">
    <div class="row">

        <div class="col-md-12">
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(Session('success')); ?>

            </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <div class="card-head-row">
                        <strong><i class="fas fa-align-left mr-2"> </i> Data Status Transaksi</strong>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="basic-datatables" style="white-space: nowrap" class="table table-bordered">
                            <thead class="">
                                <tr>
                                    <th>Kode</th>
                                    <th>Transaksi</th>
                                    <th>Detail Transaksi</th>
                                    <th>Pembayaran & Status</th>
                                    <th>Tindakan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                ?>
                                <?php $__empty_1 = true; $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="align-top"><?php echo e($no++ . ". BTK" . $dt->id); ?>RK</td>
                                    <td class="align-top">
                                        <strong>Akun : <?php echo e($dt->email_user); ?> </strong>
                                        <br><small>Penerima : <?php echo e($dt->alamat->penerima .' | '. $dt->alamat->no_hp); ?></small>
                                    </td>
                                    <td class="align-top">
                                        <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#detail<?php echo e($dt->id); ?>"><i class="fas fa-credit-card mr-2"> </i> Lihat Detail </button>
                                    </td>
                                    <td class="align-top">
                                        <?php if($dt->sudah_dibayar == 0): ?>
                                        <button class="btn btn-danger btn-sm disabled"><i class="fas fa-credit-card mr-2"> </i> Belum Dibayar</button>
                                        <?php elseif($dt->sudah_dibayar == 1): ?>
                                        <button class="btn btn-warning btn-sm disabled"><i class="fas fa-credit-card mr-2"> </i> Cek Pembayaran</button>
                                        <?php else: ?>
                                        <button class="btn btn-success btn-sm disabled"><i class="fas fa-credit-card mr-2"> </i> Sudah Dibayar</button>
                                        <?php endif; ?>


                                        <button class="btn btn-sm btn-info" <?php if($dt->status_pengiriman!='validasi' ): ?> hidden <?php endif; ?>><i class="fa fa-check-square mr-2"> </i> Validasi</button>
                                        <button class="btn btn-sm btn-info" <?php if($dt->status_pengiriman!='belum_dibayar' ): ?> hidden <?php endif; ?>><i class="fas fa-credit-card mr-2"> </i> Belum Dibayar</button>
                                        <button class="btn btn-sm btn-info" <?php if($dt->status_pengiriman!='diproses' ): ?> hidden <?php endif; ?>><i class="fa fa-hourglass-start mr-2"> </i> Diproses</button>
                                        <button class="btn btn-sm btn-info" <?php if($dt->status_pengiriman!='dikemas' ): ?> hidden <?php endif; ?>><i class="fas fa-shopping-bag mr-2"> </i> Dikemas</button>
                                        <button class="btn btn-sm btn-info" <?php if($dt->status_pengiriman!='dikirim' ): ?> hidden <?php endif; ?>><i class="fa fa-truck mr-2"> </i> Dikirim</button>
                                        <button class="btn btn-sm btn-info" <?php if($dt->status_pengiriman!='selesai' ): ?> hidden <?php endif; ?>><i class="fas fa-people-carry mr-2"> </i> Selesai</button>
                                        <button class="btn btn-sm btn-info" <?php if($dt->status_pengiriman!='dibatalkan' ): ?> hidden <?php endif; ?>><i class="fas fa-window-close mr-2"> </i> Dibatalkan</button>
                                    </td>

                                    <td class="align-top">
                                        <div class="dropdown">
                                            <button type="button" class="btn btn-secondary btn-sm dropdown-toggle" data-toggle="dropdown">
                                                Tindakan
                                            </button>
                                            <div class="dropdown-menu">
                                                <a class="dropdown-item" href="<?php echo e(route('status_transaksi.edit', $dt->id)); ?>">Ubah Status Transaksi</a>
                                                <a class="dropdown-item" data-toggle="modal" data-target="#pembayaran<?php echo e($dt->id); ?>" href="#">Ubah Status Pembayaran</a>
                                                <a class=" dropdown-item" data-toggle="modal" data-target="#komentar<?php echo e($dt->id); ?>" href="#">Lihat Komentar</a>
                                            </div>
                                        </div>
                                    </td>

                                    <div class="modal fade" id="detail<?php echo e($dt->id); ?>">
                                        <div class="modal-dialog modal-dialog-centered modal-lg">
                                            <div class="modal-content">

                                                <div class="modal-header">
                                                    <h5 class="modal-title"><strong>Detail Alamat Pengiriman - BKT<?php echo e($dt->id); ?></strong></h5>
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                </div>

                                                <div class="modal-body">
                                                    <strong>Produk: </strong><br><?php echo e("Rp " . number_format($dt->total,2,',','.')); ?>

                                                    <hr>
                                                    <strong>Ongkir: </strong><br><?php echo e("Rp " . number_format($dt->ro_cost,2,',','.')); ?>

                                                    <hr>
                                                    <strong>Total: </strong><br><?php echo e("Rp " . number_format(($dt->total + $dt->ro_cost),2,',','.')); ?>

                                                    <hr>
                                                    <strong>Resi: </strong><br><?php echo e($dt->resi); ?>

                                                    <hr>
                                                    <strong>Expedisi: </strong><br><?php echo e($dt->ro_description .' ('. $dt->ro_service .') | '. $dt->ro_etd .' hari | '. $dt->ro_name); ?>

                                                    <hr>
                                                    <strong>Alamat: </strong><br>
                                                    <?php echo e($dt->alamat->alamat .', '. $dt->alamat->nama_kec .', '. $dt->alamat->nama_kab .', '. $dt->alamat->nama_prov); ?>

                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="modal fade" id="komentar<?php echo e($dt->id); ?>">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content">

                                                <div class="modal-header">
                                                    <h5 class="modal-title"><strong>Review Pelanggan</strong></h5>
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                </div>

                                                <div class="modal-body">
                                                    <?php echo e($dt->komentar); ?>

                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="modal fade" id="pembayaran<?php echo e($dt->id); ?>">
                                        <div class="modal-dialog modal-dialog-centered modal-lg">
                                            <div class="modal-content">

                                                <div class="modal-header">
                                                    <h5 class="modal-title"><strong>Statas Pembayaran</strong></h5>
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                </div>

                                                <div class="modal-body">
                                                    <div class="col-md-12">
                                                        <form class="col" method="POST" action="<?php echo e(route('status_transaksi.update', $dt->id)); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PUT'); ?>
                                                            <div class="row">

                                                                <div class="col-md-12 form-group input-group-sm">
                                                                    <label for="inpStatusPembayaran">Status Pembayaran</label>
                                                                    <br>
                                                                    <div class="form-check-inline">
                                                                        <label class="form-check-label" for="inpStatus1">
                                                                            <input type="radio" class="form-check-input" id="inpStatus1" name="inpStatusPembayaran" value="0" <?php if($dt->sudah_dibayar == 0): ?> checked <?php endif; ?> >Belum Dibayar
                                                                        </label>
                                                                    </div>
                                                                    <div class="form-check-inline">
                                                                        <label class="form-check-label" for="inpStatus2">
                                                                            <input type="radio" class="form-check-input" id="inpStatus2" name="inpStatusPembayaran" value="1" <?php if($dt->sudah_dibayar == 1): ?> checked <?php endif; ?> >Cek Pembayaran
                                                                        </label>
                                                                    </div>
                                                                    <div class="form-check-inline">
                                                                        <label class="form-check-label" for="inpStatus3">
                                                                            <input type="radio" class="form-check-input" id="inpStatus3" name="inpStatusPembayaran" value="2" <?php if($dt->sudah_dibayar == 2): ?> checked <?php endif; ?> >Sudah Dibayar
                                                                        </label>
                                                                    </div>
                                                                </div>

                                                                <div class="col-md-6 form-group input-group-sm">
                                                                    <input class="btn btn-primary btn-sm" type="submit" class="form-control">
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8">Data Kosong...</td>
                                </tr>
                                <?php endif; ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyek\batik4_0\resources\views/content/status_transaksi/index.blade.php ENDPATH**/ ?>