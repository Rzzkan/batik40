<div class="sidebar sidebar-style-2">
    <div class="sidebar-wrapper scrollbar scrollbar-inner">
        <div class="sidebar-content">
            <div class="user">
                <div class="avatar-sm float-left mr-2">
                    <img src="<?php echo e(asset('tema/img/profile.png')); ?>" alt="..." class="avatar-img rounded-circle">
                </div>
                <div class="info">
                    <a data-toggle="collapse" href="#collapseExample" aria-expanded="true">
                        <span>
                            <?php echo e(auth()->user()->name); ?>

                            <span class="user-level"><?php echo e(auth()->user()->role); ?></span>
                            <!-- <span class="caret"></span> -->
                        </span>
                    </a>
                    <div class="clearfix"></div>
                </div>
            </div>

            <ul class="nav <?php if(auth()->user()->role == 'pelanggan'): ?> nav-warning <?php else: ?> nav-primary <?php endif; ?>">
                <li class="nav-item <?php if($title == 'Dashboard'): ?> active <?php endif; ?> ">
                    <a href="<?php echo e(route('dashboard')); ?>">
                        <i class="fas fa-home"></i>
                        <p>Dashboard</p>
                        <!-- <span class="caret"></span> -->
                    </a>
                </li>

                <?php if(auth()->user()->role=='super_admin'): ?>

                <li class="nav-section">
                    <span class="sidebar-mini-icon">
                        <i class="fa fa-ellipsis-h"></i>
                    </span>
                    <h4 class="text-section">Kelola Data</h4>
                </li>

                <li class="nav-item <?php if($title == 'Mesin'): ?> active <?php endif; ?> ">
                    <a href="<?php echo e(route('mesin.index')); ?>">
                        <i class="far fa-hdd"></i>
                        <p>Mesin</p>
                    </a>
                </li>

                <li class="nav-item <?php if($title == 'Warna'): ?> active <?php endif; ?> ">
                    <a href="<?php echo e(route('warna.index')); ?>">
                        <i class="fas fa-palette"></i>
                        <p>Warna</p>
                    </a>
                </li>

                <li class="nav-item <?php if($title == 'Teknik'): ?> active <?php endif; ?> ">
                    <a href="<?php echo e(route('teknik.index')); ?>">
                        <i class="fas fa-fill-drip"></i>
                        <p>Teknik Pewarnaan</p>
                    </a>
                </li>

                <li class="nav-item <?php if($title == 'Kain'): ?> active <?php endif; ?> ">
                    <a href="<?php echo e(route('kain.index')); ?>">
                        <i class="fas fa-paperclip"></i>
                        <p>Kain (Per 1m x 1m)</p>
                    </a>
                </li>

                <li class="nav-item <?php if($title == 'Proses'): ?> active <?php endif; ?> ">
                    <a href="<?php echo e(route('proses.index')); ?>">
                        <i class="fas fa-layer-group"></i>
                        <p>Jenis Proses</p>
                    </a>
                </li>

                <?php endif; ?>

                <?php if(auth()->user()->role=='super_admin' || auth()->user()->role=='pengelola'): ?>

                <li class="nav-section">
                    <span class="sidebar-mini-icon">
                        <i class="fa fa-ellipsis-h"></i>
                    </span>
                    <h4 class="text-section">Kelola Pesanan</h4>
                </li>

                <li class="nav-item <?php if($title == 'Validasi Harga'): ?> active <?php endif; ?> ">
                    <a href="<?php echo e(route('validasi.index')); ?>">
                        <i class="fas fa-clipboard-check"></i>
                        <p>Validasi Harga</p>
                    </a>
                </li>

                <li class="nav-item <?php if($title == 'Antrian'): ?> active <?php endif; ?> ">
                    <a href="<?php echo e(route('antrian.index')); ?>">
                        <i class="fas fa-clone"></i>
                        <p>Antrian Produksi</p>
                    </a>
                </li>

                <li class="nav-item <?php if($title == 'Proses Produksi'): ?> active <?php endif; ?> ">
                    <a href="<?php echo e(route('produksi.index')); ?>">
                        <i class="fas fa-hourglass-half"></i>
                        <p>Proses Produksi</p>
                    </a>
                </li>

                <li class="nav-item <?php if($title == 'Status Mesin'): ?> active <?php endif; ?> ">
                    <a href="<?php echo e(route('status_mesin.index')); ?>">
                        <i class="fas fa-sliders-h"></i>
                        <p>Status Mesin</p>
                    </a>
                </li>

                <li class="nav-item <?php if($title == 'Status Transaksi'): ?> active <?php endif; ?> ">
                    <a href="<?php echo e(route('status_transaksi.index')); ?>">
                        <i class="fas fa-coins"></i>
                        <p>Status Transaksi</p>
                    </a>
                </li>

                <?php endif; ?>

                <?php if(auth()->user()->role=='super_admin'): ?>

                <li class="nav-section">
                    <span class="sidebar-mini-icon">
                        <i class="fa fa-ellipsis-h"></i>
                    </span>
                    <h4 class="text-section">Data Pengguna</h4>
                </li>

                <li class="nav-item <?php if($title == 'Pengelola'): ?> active <?php endif; ?> ">
                    <a href="<?php echo e(route('pengelola.index')); ?>">
                        <i class="fas fa-users-cog"></i>
                        <p>Admin Pengelola</p>
                        <!-- <span class="badge badge-success">4</span> -->
                    </a>
                </li>

                <li class="nav-item <?php if($title == 'Pelanggan'): ?> active <?php endif; ?> ">
                    <a href="<?php echo e(route('pelanggan.index')); ?>">
                        <i class="fas fa-users"></i>
                        <p>Pelanggan</p>
                    </a>
                </li>

                <li class="nav-item <?php if($title == 'Setting'): ?> active <?php endif; ?> ">
                    <a href="<?php echo e(route('setting.index')); ?>">
                        <i class="fas fa-cogs"></i>
                        <p>Setting</p>
                    </a>
                </li>

                <?php endif; ?>

                <?php if(auth()->user()->role=='pelanggan'): ?>

                <li class="nav-section">
                    <span class="sidebar-mini-icon">
                        <i class="fa fa-ellipsis-h"></i>
                    </span>
                    <h4 class="text-section">Pelanggan</h4>
                </li>

                <li class="nav-item <?php if($title == 'Alamat'): ?> active <?php endif; ?> ">
                    <a href="<?php echo e(route('alamat.index')); ?>">
                        <i class="fas fa-map-marked-alt"></i>
                        <p>Alamat</p>
                    </a>
                </li>

                <li class="nav-item <?php if($title == 'Panduan' || 
                $title == 'Motif Dasar' || 
                $title == 'Panduan' || 
                $title == 'Hasil Desain'): ?> active <?php endif; ?> ">
                    <a data-toggle="collapse" href="#customer">
                        <i class="fas fa-clipboard-check"></i>
                        <p>Customer</p>
                        <span class="caret"></span>
                    </a>

                    <div class="collapse <?php if($title == 'Panduan' || 
                $title == 'Motif Dasar' || 
                $title == 'Panduan' || 
                $title == 'Hasil Desain'): ?> show <?php endif; ?> " id="customer">
                        <ul class="nav nav-collapse">
                            <li class="<?php if($title == 'Panduan'): ?> active <?php endif; ?> ">
                                <a href="<?php echo e(route('panduan.index')); ?>">
                                    <span class="sub-item">Panduan</span>
                                </a>
                            </li>
                            <li class="<?php if($title == 'Motif Dasar'): ?> active <?php endif; ?> ">
                                <a href="<?php echo e(route('motif.index')); ?>">
                                    <span class="sub-item">Motif Dasar</span>
                                </a>
                            </li>
                            <li class="<?php if($title == 'Pelanggan'): ?> active <?php endif; ?> ">
                                <a href="#" onclick="$('#subsdmit').trigger('click');">
                                    <span class="sub-item">Buat Desain</span>
                                </a>

                                <form target="_blank" id="form-desain" action="<?php echo e($data['data_setting']->url_desain . '/processlogin.php'); ?>" method="post" class="d-none" hidden>
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('post'); ?>

                                    <input type="text" id="username" class="fadeIn second" name="usermail" placeholder="Email" value="<?php echo e(auth()->user()->email); ?>">
                                    <input type="password" id="password" class="fadeIn third" name="password" placeholder="Password" value="<?php echo e(\App\Models\CustomerModel::where(['id' => auth()->user()->id])->first()->password); ?>">
                                    <input type="submit" id="subsdmit" name="submit" class="fadeIn fourth" value="submit">
                                </form>
                            </li>
                            <li class="<?php if($title == 'Hasil Desain'): ?> active <?php endif; ?> ">
                                <a href="<?php echo e(route('hasil_desain.index')); ?>">
                                    <span class="sub-item">Hasil</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>

                <li class="nav-item <?php if($title == 'Keranjang'): ?> active <?php endif; ?> ">
                    <a href="<?php echo e(route('keranjang.index')); ?>">
                        <i class="fas fa-shopping-cart"></i>
                        <p>Keranjang</p>
                    </a>
                </li>

                <li class="nav-item <?php if($title == 'Transaksi'): ?> active <?php endif; ?> ">
                    <a href="<?php echo e(route('transaksi.index')); ?>">
                        <i class="fas fa-hourglass-half"></i>
                        <p>Transaksi</p>
                    </a>
                </li>

                <li class="nav-section">
                    <span class="sidebar-mini-icon">
                        <i class="fa fa-ellipsis-h"></i>
                    </span>
                    <h4 class="text-section">Bantuan</h4>
                </li>

                <li class="nav-item <?php if($title == 'Happy Customer'): ?> active <?php endif; ?> ">
                    <a href="<?php echo e(route('review.index')); ?>">
                        <i class="far fa-star"></i>
                        <p>Happy Customer</p>
                    </a>
                </li>

                <li class="nav-item <?php if($title == 'Customer Service'): ?> active <?php endif; ?> ">
                    <a href="https://api.whatsapp.com/send?phone=<?php echo e($data['data_setting']->no_toko); ?>" target="_blank">
                        <i class="fas fa-sliders-h"></i>
                        <p>Customer Service</p>
                    </a>
                </li>

                <?php endif; ?>
            </ul>
        </div>
    </div>
</div><?php /**PATH D:\proyek\batik4_0\resources\views/includes/sidebar.blade.php ENDPATH**/ ?>