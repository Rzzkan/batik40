
<?php $__env->startSection('content'); ?>
<div class="page-inner mt-2">
    <div class="row">

        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-head-row">
                        <strong><i class="fas fa-align-left mr-2"> </i> Data Motif Dasar</strong><a href="<?php echo e(url()->previous()); ?>" class="btn btn-danger btn-sm ml-auto"><i class="fas fa-arrow-left mr-2"> </i> Back</a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="basic-datatables" class="table table-bordered table-hover">
                            <thead class="thead-light">
                                <tr>
                                    <th>No.</th>
                                    <th>Nama Motif</th>
                                    <th>Gambar Motif</th>
                                    <th>Karakter</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                ?>
                                <?php $__empty_1 = true; $__currentLoopData = $motif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($dt->motif_nama); ?></td>
                                    <td><img height="80px" src="<?php echo e(asset('customer/img') . '/' . $dt->motif_file); ?>"></td>
                                    <td>
                                        <?php $__currentLoopData = $karakter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt_kar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($dt_kar->motif_id == $dt->motif_id): ?>
                                        <?php echo e($dt_kar->nama_karakter . ", "); ?>

                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="4">Data Kosong...</td>
                                </tr>
                                <?php endif; ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyek\batik4_0\resources\views/customer/motif/index.blade.php ENDPATH**/ ?>