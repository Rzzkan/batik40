
<?php $__env->startSection('content'); ?>
<div class="page-inner mt--5">
    <div class="row">

        <div class="col-md-6">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <div class="card-head-row">
                        <strong><i class="fas fa-clipboard-check mr-2"> </i> Rincian Pesanan </strong>
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-danger btn-sm ml-auto"><i class="fas fa-arrow-left mr-2"> </i> Back</a>
                    </div>
                </div>
                <div class="card-body">
                    <?php
                    $total = 0;
                    ?>
                    <div class="col-12">
                        <?php $__currentLoopData = $validasi->produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $harga = ($dt->biaya_mesin + $dt->biaya_warna + $dt->biaya_teknik + $dt->biaya_kain) * $dt->jumlah * (($dt->lebar_kain / 100) * ($dt->tinggi_kain / 100));
                        $total = $total + $harga;
                        ?>
                        <div class="row">
                            <div class="col-2">
                                <img src="<?php echo e($data['data_setting']->base_url_img_desain_batik . '/' . $dt->file_batik); ?>" width="100%" style="border: 1px solid gray;">
                            </div>
                            <div class="col">
                                <strong><?php echo e(strtoupper($dt->nama_batik)); ?></strong>
                                <p class="card-text">
                                    <?php echo e("Warna: " . $dt->nama_warna . ", teknik: " . $dt->nama_teknik . ", kain: " . $dt->nama_kain . " | Jumlah: " . $dt->jumlah); ?>

                                    <br>
                                    <strong><?php echo e("Rp " . number_format($harga,2,',','.')); ?></strong>
                                </p>
                            </div>
                        </div>
                        <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="col-12">
                        <h4><strong>Total: </strong></h4>
                        <h2><strong><?php echo e("Rp " . number_format($total,2,',','.')); ?></strong></h2>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <div class="card-head-row">
                        <strong><i class="fas fa-clipboard-check mr-2"> </i> Validasi Harga - Edit <?php echo e('BTK' . $validasi->id); ?> </strong><a href="<?php echo e(url()->previous()); ?>" class="btn btn-danger btn-sm ml-auto"><i class="fas fa-arrow-left mr-2"> </i> Back</a>
                    </div>
                </div>
                <div class="card-body">
                    <form class="col" method="POST" action="<?php echo e(route('validasi.update', $validasi->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row">

                            <div class="col-md-12 form-group input-group-sm">
                                <label for="inpTotal">Harga Produk - <?php echo e("Rp " . number_format($validasi->total,2,',','.')); ?></label>
                                <input type="number" class="form-control" placeholder="" id="inpTotal" name="inpTotal" value="<?php echo e($validasi->total); ?>">
                            </div>

                            <?php if($validasi->status == 'menunggu'): ?>
                            <div class="col-md-12 form-group input-group-sm">
                                <label for="inpKode">Validasi Harga</label>
                                <br>
                                <div class="form-check-inline">
                                    <label class="form-check-label" for="inpStatus1">
                                        <input type="radio" class="form-check-input" id="inpStatus1" name="inpStatus" value="menunggu" <?php if($validasi->status == 'menunggu'): ?> checked <?php endif; ?> >Menawarkan
                                    </label>
                                </div>

                                <div class="form-check-inline">
                                    <label class="form-check-label" for="inpStatus2">
                                        <input type="radio" class="form-check-input" id="inpStatus2" name="inpStatus" value="siap_diantrikan" <?php if($validasi->status == 'siap_diantrikan'): ?> checked <?php endif; ?> >Terima dan Siap Diantrikan
                                    </label>
                                </div>

                                <div class="form-check-inline">
                                    <label class="form-check-label" for="inpStatus3">
                                        <input type="radio" class="form-check-input" id="inpStatus3" name="inpStatus" value="batal" <?php if($validasi->status == 'batal'): ?> checked <?php endif; ?> >Tolak atau Batalkan
                                    </label>
                                </div>
                            </div>

                            <div class="col-md-6 form-group input-group-sm">
                                <input class="btn btn-primary btn-sm" type="submit" class="form-control">
                            </div>
                            <?php else: ?>
                            <div class="col-md-6 form-group input-group-sm">
                                - Pesanan telah diproduksi.
                            </div>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyek\batik4_0\resources\views/content/validasi/edit.blade.php ENDPATH**/ ?>